const express = require('express');
const router = express.Router();
const service = require('./service');


/* GET programming languages. */
router.get('/odba', async function(req, res, next) {
  try {
    res.json(await service.readdatafromdb(req.query.page));
  } catch (err) {
    console.error(`Error while getting programming languages `, err.message);
    next(err);
  }
});
router.get('/json', async function(req, res, next) {
    try {
      res.json(await service.Readjson(req.myJSON));
    } catch (err) {
      console.error(`Error while getting programming languages `, err.message);
      next(err);
    }
  });

  

  router.post('/dropdown',async function(req,res,next){
       console.log("Message sent successfully");

    //res.json(await service.Readjson(req.myJSON));
    console.log(req.body.name); 
   res.send(req.body.name);
   console.log("Message sent successfully");
  });
  /*router.post('/dropdown',async function (req, res)  {
    debugger;
  const selectedOption = req.body.name;
  //console.log(selectedOption);
  //res.send(selectedOption);
  //await service.Accountdropdown(selectedOption);
  if(err){
    res.send("Error encountered while displaying");
    return console.error(err.message);
  }
  //res.json(await service.Accountdropdown(req.body.name));

  res.send(req.body.name);
  console.log("Entry displayed successfully");
});
*/
  // Do something with the selected option

router.get('/benefitplan', async function(req, res, next) {
  try {
    res.json(await service.benefitplan());
  } catch (err) {
    console.error(`Error while getting programming languages `, err.message);
    next(err);
  }
});


module.exports = router;
