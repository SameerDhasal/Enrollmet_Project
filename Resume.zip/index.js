const express = require("express");
const bodyparser=require('body-parser');
const app = express();
const port = 5000;
const router = require("./router");
const bodyParser = require("body-parser");

app.get("/", (req, res) => { res.json({ message: "ok" });});

app.use(express.static('dist'));
app.get('/', function (req, res) {
    res.sendFile('index.html', { root: __dirname });
});
app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`);
  });
  
  //app.use("/", router);

  app.use("/dropdown", router);


  app.use(bodyparser.json());
  app.use(bodyparser.urlencoded({extended:true}));

