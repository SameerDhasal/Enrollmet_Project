const config = {
    db: {
      /* don't expose password or any sensitive info, done only for demo */
      user: 'citi_abagchi',
      password: 'U4ggPVAg9PNuJ',
      connectString: '100.112.45.151:1521/CITPDWTT'
    },
    listPerPage: 100,
  };
  module.exports = config;